package ma.enset.hospitalapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
